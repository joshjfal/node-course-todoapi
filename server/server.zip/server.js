var mongoose = require("mongoose");

mongoose.Promise = global.Promise; // Tells mongo.Promise to use the Global promise (and not a third-party promise, which is where "promise" originated before becoming part of JS)

mongoose.connect("mongodb://localhost:27017/TodoApp");

//Model name and then property (being an object in below example)
var Todo = mongoose.model("Todo", {
  text: {
    type: String, //Field type
    required: true, //This field is required
    minlength: 1, //Minimum length of this field
    trim: true //Removes leading white space (i.e. if todo was as blank space it would pass minlength but trim would cause it to error).
  },
  completed: {
    type: Boolean,
    defalt: false //Set a default for Boolean
  },
  completedAt: {
    type: Number,
    default: null //Not completed yet
  }
});

// new instance of Todo..
// var newTodo = new Todo({
//   text: 'Cook dinner'
// })

var newTodo = new Todo({
  text: 'Test'
});

// //Save returns a promise
// newTodo.save().then((doc) => {
//   console.log("Saved todo: ", doc);
// }, (e) => {
//   console.log("Unable to save todo");
// });

/* ----------------------------------------------------------------------------------------- */

var addUser = mongoose.model("addUser", {
  fullname: {
    type: String,
    required: true,
    minlength: 1,
    trim: true
  },
  email: {
    type: String,
    required: true,
    minlength: 1,
    trim: true
  },
  age: {
    type: Number
  }
});

var nowAddUser = new addUser({
  fullname: "Josh Janisch",
  email: "josh@janisch.co.uk",
  age: 26
})

nowAddUser.save().then((doc) => {
  console.log("Created new user", doc);
}, (e) => {
  console.log("Unable to save new user.");
});
